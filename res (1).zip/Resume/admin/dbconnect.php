<?php

	$link=mysqli_connect("localhost","root","","wtproject2017") or die("Error: connecting database.".mysqli_connect_error());

?>